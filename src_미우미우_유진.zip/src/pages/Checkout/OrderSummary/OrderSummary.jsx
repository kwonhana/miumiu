import React from 'react';

const OrderSummary = () => {
  return (
    <section className="OrderSummary-wrap">
      {/* <div className="summary-left">
        <div className="top">
          <p>구입하신 상품의 수령 방법을 선택하세요.</p>
          <ul>
            <li>1. 주문서 작성 </li>
            <li>&nbsp; &gt;&nbsp; 2. 배송정보</li>
            <li>&nbsp; &gt;&nbsp; 3. 결제하기 </li>
          </ul>
        </div>
        <div className="tab-menu">
          <button
            type="button"
            className={activeTab === 'delivery' ? 'active' : ''}
            onClick={() => setActiveTab('delivery')}>
            주소지로 배송
          </button>
          <button
            type="button"
            className={activeTab === 'store' ? 'active' : ''}
            onClick={() => setActiveTab('store')}>
            매장에서 수령
          </button>
        </div>
      </div>
      <div className="summary-left">

      </div> */}
    </section>
  );
};

export default OrderSummary;
