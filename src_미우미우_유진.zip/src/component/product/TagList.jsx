import React from 'react';

export const TagList = () => {
  return <div>태그 정렬</div>;
};
