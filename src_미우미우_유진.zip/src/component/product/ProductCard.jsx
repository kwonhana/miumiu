import React from 'react';

const ProductCard = () => {
  return <div>상품 하나를 보여주는 카드 ui</div>;
};

export default ProductCard;
