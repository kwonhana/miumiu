import React from 'react';

const SkeletonCard = () => {
  return <div>카드 스켈레톤</div>;
};

export default SkeletonCard;
