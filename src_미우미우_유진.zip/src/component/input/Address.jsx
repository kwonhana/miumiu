import React, { useState } from 'react';
import './scss/Input.scss';

const Address = (value, onChange) => {
  const [address, setAddress] = useState('');

  const handleAddress = (a) => {
    if (!address) setAddress(true);
    setAddress(a);
    console.log(a);
  };

  return (
    <div className="base-input">
      <p>주소*</p>
      <input
        type="text"
        placeholder="주소를 입력해주세요"
        value={address}
        onChange={(e) => handleAddress(e.target.value)}
      />
    </div>
  );
};

export default Address;
