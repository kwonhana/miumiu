import './scss/Input.scss';
import React from 'react';

const DropBox = ({ title, list }) => {
  return (
    <></>
    // <div className="base-input">
    //   <div className="dropBox-top">
    //     <span>{title}</span>
    //   </div>
    //   <ul className="dropBox-bottom">
    //     {list?.map((el) => (
    //       <li>{el}</li>
    //     ))}
    //   </ul>
    // </div>
  );
};

export default DropBox;
