사용자 피드백 요소들 (모달, 스피너, 토스트 등)
예: <LoadingSpinner />, <Toast />, <Modal />