도메인에 특화된 UI 컴포넌트
예: <ProductCard />, <Pagination />