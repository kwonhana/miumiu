import React from 'react';

const SortDropdown = () => {
  return <div>인기순/최신순/낮은 가격 순 등 드롭다운.</div>;
};

export default SortDropdown;
