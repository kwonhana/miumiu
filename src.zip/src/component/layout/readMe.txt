전체 레이아웃을 구성하는 요소들
예: <Header />, <Footer />, <Sidebar />