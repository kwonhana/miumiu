import React from 'react';

const OrderTotal = () => {
  return <div>결제 페이지 총 결제 금액</div>;
};

export default OrderTotal;
