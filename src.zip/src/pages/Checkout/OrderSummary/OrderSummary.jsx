import React from 'react';

const OrderSummary = () => {
  return <div>전체 주문 정보 요약 </div>;
};

export default OrderSummary;
