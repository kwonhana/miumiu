import React from 'react';

const OrderComplete = () => {
  return <div>주문 완료 후 나오는 페이지</div>;
};

export default OrderComplete;
