import React from 'react';

const Payment = () => {
  return <div>결제 수단, 카드정보입력 등등. </div>;
};

export default Payment;
