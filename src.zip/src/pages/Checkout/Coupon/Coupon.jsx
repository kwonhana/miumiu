import React from 'react';

export const Coupon = () => {
  return <div>Coupon</div>;
};
