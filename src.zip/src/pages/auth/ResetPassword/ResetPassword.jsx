import React from 'react';

const ResetPassword = () => {
  return <div>비밀번호 찾기</div>;
};

export default ResetPassword;
