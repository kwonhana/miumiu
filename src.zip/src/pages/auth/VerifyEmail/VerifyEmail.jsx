import React from 'react';

const VerifyEmail = () => {
  return <div>이메일 인증</div>;
};

export default VerifyEmail;
