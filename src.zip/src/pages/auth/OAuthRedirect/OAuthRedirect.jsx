import React from 'react';

const OAuthRedirect = () => {
  return <div>소셜 로그인 리디렉션 처리용</div>;
};

export default OAuthRedirect;
