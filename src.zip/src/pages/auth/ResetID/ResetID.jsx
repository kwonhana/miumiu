import React from 'react';

const ResetID = () => {
  return <div>아이디 찾기</div>;
};

export default ResetID;
