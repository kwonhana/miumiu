// import { create } from 'zustand';

// export const useHeaderStore = create((set, get) => ({
//   scrollY: 0,
//   setScrollY: (res) => {
//     set({ scrollY: res });
//   },
// }));
